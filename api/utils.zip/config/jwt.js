module.exports = {
    secret: 'yoursecretkey'
  };
  